package com.example.jorgepuchawebservices.interfaces;

import com.example.jorgepuchawebservices.fragmentos.FragmentoBuscar;

public interface iFragmentos extends FragmentoBuscar.OnFragmentInteractionListener{
}
