package com.example.jorgepuchawebservices.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.jorgepuchawebservices.R;
import com.example.jorgepuchawebservices.modelo.Licor;

import java.util.ArrayList;
import java.util.List;

public class AdapterLicor extends BaseAdapter {
    private Context context;
    private List<Licor> listaLicor;
    public AdapterLicor(Context context, List<Licor> listaLicor) {
        this.context = context;
        this.listaLicor = listaLicor;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public List<Licor> getListaLicor() {
        return listaLicor;
    }

    public void setListaLicor(List<Licor> listaLicor) {
        this.listaLicor = listaLicor;
    }



    @Override
    public int getCount() {
        return listaLicor.size();

    }

    @Override
    public Object getItem(int position) {
        return listaLicor.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = View.inflate(context,R.layout.display_general, null);
        TextView txtID = (TextView) convertView.findViewById(R.id.lblid);
        TextView txtName = (TextView) convertView.findViewById(R.id.lblName);
        TextView txtYear = (TextView) convertView.findViewById(R.id.lblYear);
        TextView txtGrapes = (TextView) convertView.findViewById(R.id.lblgrapes);
        TextView txtCountry = (TextView) convertView.findViewById(R.id.lblcountry);
        TextView txtRegion = (TextView) convertView.findViewById(R.id.lblregion);
        TextView txtDescripcion = (TextView) convertView.findViewById(R.id.lbldescripcion);
        TextView txtPicture = (TextView) convertView.findViewById(R.id.lblpicture);

        Licor licor = listaLicor.get(position);
        txtID.setText(String.valueOf(licor.getId()));
        txtName.setText(licor.getName());
        txtYear.setText(licor.getYear());
        txtGrapes.setText(String.valueOf(licor.getGrapes()));
        txtCountry.setText(licor.getCountry());
        txtRegion.setText(licor.getRegion());
        txtDescripcion.setText(String.valueOf(licor.getDescription()));
        txtPicture.setText(licor.getPicture());
        return convertView;
    }
}
